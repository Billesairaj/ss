package com.procurement.system.procurement_system.Entity;

import jakarta.persistence.*;
import lombok.Data;

import java.util.Date;

@Data
@Entity
public class ApprovalRejection {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String requestedBy;
    private String requisitionNumber;
    private Date requestedDate;
    private String status;

}