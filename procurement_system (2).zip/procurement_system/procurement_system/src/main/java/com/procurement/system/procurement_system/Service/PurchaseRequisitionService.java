package com.procurement.system.procurement_system.Service;

import com.procurement.system.procurement_system.Entity.PurchaseRequisition;

public interface PurchaseRequisitionService {
 

	long createPurchaseRequisition(PurchaseRequisition request);

	String approveOrRejectPurchaseRequisition(Long requisitionId, String status);

	PurchaseRequisition savePurchaseRequisition(PurchaseRequisition requisition);

}