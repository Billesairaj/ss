package com.procurement.system.procurement_system.Service;

import com.procurement.system.procurement_system.Entity.PurchaseRequisitionLine;

public interface PurchaseRequisitionLineService {
    PurchaseRequisitionLine createPurchaseRequisitionLine(PurchaseRequisitionLine purchaseRequisitionLine);
}