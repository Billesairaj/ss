package com.procurement.system.procurement_system.Controller;

import com.procurement.system.procurement_system.Entity.PurchaseRequisitionLine;
import com.procurement.system.procurement_system.Service.PurchaseRequisitionLineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PurchaseRequisitionLineController {

    @Autowired
    private PurchaseRequisitionLineService purchaseRequisitionLineService;

    @PostMapping("/purchaserequisitionline")
    public ResponseEntity<String> createPurchaseRequisitionLine(@RequestBody PurchaseRequisitionLine purchaseRequisitionLine) {
        PurchaseRequisitionLine createdLine = purchaseRequisitionLineService.createPurchaseRequisitionLine(purchaseRequisitionLine);
        Long requisitionId = createdLine.getRequisitionId(); // Get manually provided requisition ID
        String message = "Purchase Requisition line added successfully - " + requisitionId;
        return new ResponseEntity<>(message, HttpStatus.CREATED);
    }
}