package com.procurement.system.procurement_system.Entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
public class PurchaseRequisitionLine {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long requisitionId; // Manually provided requisition ID

    private int serialNumber;
    private String product;
    private double unitPrice;
    private int quantityRequired;
    private double total;

    // Constructors, getters, setters
}