package com.procurement.system.procurement_system.Entity;
import java.util.Date;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class PurchaseRequisition {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String requestedBy;
    private Date requestedDate;
    private Date expectedDate;
    private String managerName;
    private String vendorName;
	public void setStatus(Object status) {
		// TODO Auto-generated method stub
		
	}

   
}