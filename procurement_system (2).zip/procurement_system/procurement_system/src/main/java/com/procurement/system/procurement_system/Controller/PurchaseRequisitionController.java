package com.procurement.system.procurement_system.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.procurement.system.procurement_system.Entity.PurchaseRequisition;
import com.procurement.system.procurement_system.Service.PurchaseRequisitionService;

@RestController
@RequestMapping("/purchase-requisitions")
public class PurchaseRequisitionController {

    @Autowired
    private PurchaseRequisitionService purchaseRequisitionService;

    @PostMapping("/create")
    public ResponseEntity<String> createPurchaseRequisition(@RequestBody PurchaseRequisition request) {
        Long requisitionId = purchaseRequisitionService.createPurchaseRequisition(request);
        return ResponseEntity.ok("Requisition created successfully. ID: " + requisitionId);
    }
}