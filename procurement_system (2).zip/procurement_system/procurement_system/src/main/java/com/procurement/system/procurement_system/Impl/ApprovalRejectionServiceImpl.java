package com.procurement.system.procurement_system.Impl;

import com.procurement.system.procurement_system.Entity.ApprovalRejection;
import com.procurement.system.procurement_system.Repository.ApprovalRejectionRepository;
import com.procurement.system.procurement_system.Service.ApprovalRejectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ApprovalRejectionServiceImpl implements ApprovalRejectionService {

    @Autowired
    private ApprovalRejectionRepository approvalRejectionRepository;

    @Override
    public ApprovalRejection createApprovalRejection(ApprovalRejection approvalRejection) {
        return approvalRejectionRepository.save(approvalRejection);
    }
}