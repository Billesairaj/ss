package com.procurement.system.procurement_system.Impl;

import com.procurement.system.procurement_system.Entity.PurchaseRequisition;
import com.procurement.system.procurement_system.Repository.PurchaseRequisitionRepository;
import com.procurement.system.procurement_system.Service.PurchaseRequisitionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PurchaseRequisitionServiceImpl implements PurchaseRequisitionService {

    @Autowired
    private PurchaseRequisitionRepository purchaseRequisitionRepository;

    @Override
    public long createPurchaseRequisition(PurchaseRequisition request) {
        PurchaseRequisition savedRequisition = purchaseRequisitionRepository.save(request);
        return savedRequisition.getId(); // Assuming PurchaseRequisition has an ID field
    }


	@Override
	public PurchaseRequisition savePurchaseRequisition(PurchaseRequisition requisition) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public String approveOrRejectPurchaseRequisition(Long requisitionId, String status) {
		// TODO Auto-generated method stub
		return null;
	}

}