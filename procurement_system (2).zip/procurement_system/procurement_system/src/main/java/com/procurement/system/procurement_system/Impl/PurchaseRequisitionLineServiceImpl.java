package com.procurement.system.procurement_system.Impl;

import com.procurement.system.procurement_system.Entity.PurchaseRequisitionLine;
import com.procurement.system.procurement_system.Repository.PurchaseRequisitionLineRepository;
import com.procurement.system.procurement_system.Service.PurchaseRequisitionLineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PurchaseRequisitionLineServiceImpl implements PurchaseRequisitionLineService {

    @Autowired
    private PurchaseRequisitionLineRepository purchaseRequisitionLineRepository;

    @Override
    public PurchaseRequisitionLine createPurchaseRequisitionLine(PurchaseRequisitionLine purchaseRequisitionLine) {
        return purchaseRequisitionLineRepository.save(purchaseRequisitionLine);
    }
}