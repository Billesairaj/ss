package com.procurement.system.procurement_system.Controller;

import com.procurement.system.procurement_system.Entity.ApprovalRejection;
import com.procurement.system.procurement_system.Service.ApprovalRejectionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ApprovalRejectionController {

    @Autowired
    private ApprovalRejectionService approvalRejectionService;

    @PostMapping("/approvalrejection")
    public ResponseEntity<ApprovalRejection> createApprovalRejection(@RequestBody ApprovalRejection approvalRejection) {
        ApprovalRejection createdApprovalRejection = approvalRejectionService.createApprovalRejection(approvalRejection);
        return new ResponseEntity<>(createdApprovalRejection, HttpStatus.CREATED);
    }
}