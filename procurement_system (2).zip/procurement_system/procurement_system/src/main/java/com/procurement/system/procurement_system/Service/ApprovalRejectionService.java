package com.procurement.system.procurement_system.Service;

import com.procurement.system.procurement_system.Entity.ApprovalRejection;

public interface ApprovalRejectionService {
    ApprovalRejection createApprovalRejection(ApprovalRejection approvalRejection);
}