package com.procurement.system.procurement_system.Repository;

import com.procurement.system.procurement_system.Entity.ApprovalRejection;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ApprovalRejectionRepository extends JpaRepository<ApprovalRejection, Long> {
}