package com.procurement.system.procurement_system.Repository;

import com.procurement.system.procurement_system.Entity.PurchaseRequisitionLine;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PurchaseRequisitionLineRepository extends JpaRepository<PurchaseRequisitionLine, Long> {
}